import React from "react";
import { motion } from "framer-motion";
import { CheckCircle2, Building2, GraduationCap, HeartPulse, Shield, Cpu, Phone, Mail, ArrowRight, FileText, Globe2 } from "lucide-react";
import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";
import { Input, Textarea } from "./components/ui/input";

export default function CanCultureMediaSite() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white text-slate-800">
      {/* Nav */}
      <header className="sticky top-0 z-50 backdrop-blur bg-white/70 border-b border-slate-200">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Globe2 className="h-6 w-6 text-sky-600" />
            <span className="font-semibold tracking-tight">Can Culture Media, LLC</span>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#solutions" className="hover:text-sky-700">Solutions</a>
            <a href="#about" className="hover:text-sky-700">About</a>
            <a href="#cases" className="hover:text-sky-700">Case Studies</a>
            <a href="#resources" className="hover:text-sky-700">Resources</a>
            <a href="#contact" className="hover:text-sky-700">Contact</a>
          </nav>
          <div className="flex items-center gap-2">
            <a href="#contact"><Button className="rounded-2xl">Book a Discovery Call</Button></a>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="max-w-6xl mx-auto px-4 py-16 md:py-24 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <motion.h1 
              initial={{opacity:0, y:10}} 
              animate={{opacity:1, y:0}}
              transition={{duration:0.6}}
              className="text-4xl md:text-5xl font-bold leading-tight tracking-tight">
              Empowering organizations to care for people and perform with purpose.
            </motion.h1>
            <p className="mt-4 text-lg text-slate-600">
              We help employers and nonprofits create healthier, more efficient workplaces through
              tax-smart wellness benefits and workforce development that actually sticks.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href="#solutions"><Button size="lg" className="rounded-2xl">See Solutions <ArrowRight className="ml-2 h-4 w-4"/></Button></a>
              <a href="#contact"><Button size="lg" variant="outline" className="rounded-2xl">Get a Free Payroll Wellness Audit</Button></a>
            </div>
            <ul className="mt-6 grid sm:grid-cols-3 gap-3 text-sm">
              {["Zero net cost to employers","Increase take-home pay","Reduce payroll tax burden"].map((i) => (
                <li key={i} className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-600"/>{i}</li>
              ))}
            </ul>
          </div>
          <motion.div 
            initial={{opacity:0, y:10}} 
            animate={{opacity:1, y:0}}
            transition={{delay:0.1, duration:0.6}}
            className="grid grid-cols-2 gap-4">
            {[
              {icon: HeartPulse, title: "Capstone Wellness", desc: "ACA §125 indemnity-based wellness that boosts pay + cuts FICA."},
              {icon: GraduationCap, title: "LPaaS Automation", desc: "Transform SOPs and product knowledge into trackable learning and certifications."},
              {icon: Shield, title: "Compliance-first", desc: "Aligned with 2024 tri-agency guidance; evidence-based."},
              {icon: Cpu, title: "Plug & Play", desc: "Fast onboarding, co-brand options, coaching + TA."},
            ].map(({icon:Icon, title, desc}) => (
              <Card key={title} className="rounded-2xl shadow-sm">
                <CardContent className="p-5">
                  <Icon className="h-6 w-6 text-sky-600"/>
                  <h3 className="mt-3 font-semibold">{title}</h3>
                  <p className="text-sm text-slate-600 mt-1">{desc}</p>
                </CardContent>
              </Card>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Solutions */}
      <section id="solutions" className="py-16 md:py-24 bg-slate-50">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Solutions</h2>
          <p className="mt-2 text-slate-600">Two pillars, one mission: care for people, elevate performance.</p>
          <Tabs defaultValue="wellness" className="mt-8">
            <TabsList className="rounded-2xl">
              <TabsTrigger value="wellness">Capstone Wellness Benefits</TabsTrigger>
              <TabsTrigger value="lpaas">Workforce Development & SOP Automation</TabsTrigger>
            </TabsList>
            <TabsContent value="wellness" className="mt-6">
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="rounded-2xl">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-semibold">Tax-smart wellness with real outcomes</h3>
                    <ul className="mt-3 space-y-2 text-slate-700 text-sm">
                      <li className="flex gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5"/> Saves employers ~$700–$850 per participating employee annually</li>
                      <li className="flex gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5"/> Increases employee take-home pay by ~$80–$170/month</li>
                      <li className="flex gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5"/> 24/7 telehealth, mental health, Rx, legal, ID protection</li>
                      <li className="flex gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5"/> ACA §125 indemnity-based wellness; compliance-first</li>
                    </ul>
                    <div className="mt-5 flex gap-3">
                      <a href="#contact"><Button className="rounded-2xl">Request Employer Audit</Button></a>
                      <a href="#resources"><Button variant="outline" className="rounded-2xl">View Program Brief</Button></a>
                    </div>
                  </CardContent>
                </Card>
                <Card className="rounded-2xl">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-semibold">Who it’s for</h3>
                    <div className="grid sm:grid-cols-2 gap-3 mt-3 text-sm">
                      {["Employers 25–500+ employees","HR & People Leaders","Benefits Brokers & PEOs","Nonprofits with payroll"].map(x => (
                        <div key={x} className="p-3 rounded-xl bg-white border border-slate-200">{x}</div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="lpaas" className="mt-6">
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="rounded-2xl">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-semibold">Learning Platform as a Service (LPaaS)</h3>
                    <ul className="mt-3 space-y-2 text-slate-700 text-sm">
                      <li className="flex gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5"/> 50+ EES-aligned micro-courses for workforce skills</li>
                      <li className="flex gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5"/> Convert SOPs & product knowledge into on-demand, trackable learning</li>
                      <li className="flex gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5"/> Assign certifications or completion credits automatically</li>
                      <li className="flex gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5"/> Bill Medicaid (H2014) or integrate into HR performance systems</li>
                    </ul>
                    <div className="mt-5 flex gap-3">
                      <a href="#contact"><Button className="rounded-2xl">Schedule a Demo</Button></a>
                      <a href="#resources"><Button variant="outline" className="rounded-2xl">Download LPaaS One-Pager</Button></a>
                    </div>
                  </CardContent>
                </Card>
                <Card className="rounded-2xl">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-semibold">Who it’s for</h3>
                    <div className="grid sm:grid-cols-2 gap-3 mt-3 text-sm">
                      {["Nonprofits & Workforce Programs","Employers & HR Teams","Schools & Training Providers","Product & Operations Managers"].map(x => (
                        <div key={x} className="p-3 rounded-xl bg-white border border-slate-200">{x}</div>
                      ))}
                    </div>
                    <div className="mt-6 border-t pt-4">
                      <h4 className="font-semibold mb-2">Use Cases</h4>
                      <div className="grid sm:grid-cols-2 gap-2 text-sm">
                        {[
                          "Train new hires faster and consistently",
                          "Automate SOP and compliance training",
                          "Certify staff on key product knowledge",
                          "Create internal micro-learning academies",
                          "Track completion for audits and HR records",
                        ].map(item => (
                          <div key={item} className="p-2 rounded-lg bg-slate-100 border border-slate-200">{item}</div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* About */}
      <section id="about" className="py-16 md:py-24">
        <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-10 items-start">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight">About Can Culture Media</h2>
            <p className="mt-3 text-slate-600">
              Founded by <strong>Richard Park</strong> in Salem, Oregon, Can Culture Media, LLC brings together licensed
              insurance expertise, employer benefits strategy, and workforce development know‑how to
              deliver measurable results. We partner nationally with employers, nonprofits, and schools to
              align culture, care, and performance.
            </p>
            <div className="mt-4 grid sm:grid-cols-2 gap-3 text-sm">
              {[
                {icon: Building2, text: "Oregon-registered LLC"},
                {icon: Shield, text: "Compliance-first operations"},
                {icon: HeartPulse, text: "People & performance focus"},
                {icon: Cpu, text: "Scalable, tech-enabled delivery"},
              ].map(({icon:Icon, text}) => (
                <div key={text} className="flex items-center gap-2 p-3 rounded-xl border border-slate-200 bg-white">
                  <Icon className="h-5 w-5 text-sky-600"/>
                  <span>{text}</span>
                </div>
              ))}
            </div>
          </div>
          <Card className="rounded-2xl">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold">What makes us different</h3>
              <ul className="mt-3 space-y-2 text-slate-700 text-sm">
                <li className="flex gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5"/> Integrated approach: wellness + learning</li>
                <li className="flex gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5"/> ROI-first design: tax savings & retention</li>
                <li className="flex gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5"/> Fast start: templates, onboarding, TA</li>
                <li className="flex gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-600 mt-0.5"/> Story-driven culture building</li>
              </ul>
              <div className="mt-5"><a href="#contact"><Button className="rounded-2xl">Talk to Richard</Button></a></div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Case Studies */}
      <section id="cases" className="py-16 md:py-24 bg-slate-50">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Case Studies (Coming Soon)</h2>
          <p className="mt-2 text-slate-600">We’re compiling short before/after snapshots with employer and nonprofit partners.</p>
          <div className="grid md:grid-cols-3 gap-4 mt-6">
            {[1,2,3].map(i => (
              <Card key={i} className="rounded-2xl">
                <CardContent className="p-5">
                  <h3 className="font-semibold">Pilot {i}</h3>
                  <p className="text-sm text-slate-600 mt-1">Add metrics like payroll tax savings, take‑home pay lift, retention increase, and training completions.</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Resources */}
      <section id="resources" className="py-16 md:py-24">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Resources</h2>
          <p className="mt-2 text-slate-600">Program briefs and compliance overviews for quick stakeholder review.</p>
          <div className="grid md:grid-cols-2 gap-4 mt-6">
            {[
              {title: "Capstone Wellness – One Pager", desc: "Benefits, savings model, and how payroll integrates.", cta: "Open One-Pager"},
              {title: "LPaaS (EES) – Executive Summary", desc: "Platform features, Medicaid alignment, sample courses.", cta: "Open Executive Summary"},
            ].map(({title, desc, cta}) => (
              <Card key={title} className="rounded-2xl">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h3 className="font-semibold">{title}</h3>
                      <p className="text-sm text-slate-600 mt-1">{desc}</p>
                    </div>
                    <FileText className="h-5 w-5 text-sky-600"/>
                  </div>
                  <div className="mt-4"><Button variant="outline" className="rounded-2xl">{cta}</Button></div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-16 md:py-24 bg-slate-50">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Get in touch</h2>
          <p className="mt-2 text-slate-600">Book a discovery call or request a payroll wellness audit. We’ll reply within one business day.</p>
          <div className="grid md:grid-cols-3 gap-6 mt-8">
            <Card className="rounded-2xl md:col-span-2">
              <CardContent className="p-6">
                <form className="grid gap-4" onSubmit={(e)=>e.preventDefault()}>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <Input placeholder="Full name" required />
                    <Input type="email" placeholder="Work email" required />
                  </div>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <Input placeholder="Organization" />
                    <Input placeholder="# Employees" />
                  </div>
                  <Textarea placeholder="How can we help?" className="min-h-[120px]" />
                  <div className="flex gap-3">
                    <Button className="rounded-2xl" type="submit">Send Message</Button>
                    <Button variant="outline" className="rounded-2xl" type="button">Request Audit</Button>
                  </div>
                </form>
              </CardContent>
            </Card>
            <div className="space-y-4">
              <Card className="rounded-2xl">
                <CardContent className="p-5 text-sm">
                  <div className="flex items-center gap-2 font-semibold"><Phone className="h-4 w-4 text-sky-600"/> Phone</div>
                  <div className="mt-1 text-slate-600">(503) 409-1453</div>
                </CardContent>
              </Card>
              <Card className="rounded-2xl">
                <CardContent className="p-5 text-sm">
                  <div className="flex items-center gap-2 font-semibold"><Mail className="h-4 w-4 text-sky-600"/> Email</div>
                  <div className="mt-1 text-slate-600">richp1080@gmail.com</div>
                </CardContent>
              </Card>
              <Card className="rounded-2xl">
                <CardContent className="p-5 text-sm">
                  <div className="font-semibold">Headquarters</div>
                  <div className="mt-1 text-slate-600">Salem, Oregon • Serving clients nationwide</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 py-8">
        <div className="max-w-6xl mx-auto px-4 text-sm text-slate-600 flex flex-col md:flex-row items-center justify-between gap-3">
          <div>© {new Date().getFullYear()} Can Culture Media, LLC. All rights reserved.</div>
          <div className="flex items-center gap-4">
            <a href="#" className="hover:text-slate-900">Privacy</a>
            <a href="#" className="hover:text-slate-900">Terms</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
