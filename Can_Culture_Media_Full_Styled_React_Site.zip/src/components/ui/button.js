import React from 'react';
export function Button({ children, className = "", variant="default", size="base", ...props }) {
  const base = "inline-flex items-center justify-center font-medium transition focus:outline-none focus:ring-2 focus:ring-sky-500";
  const rounded = "rounded-md";
  const sizes = {
    base: "px-4 py-2 text-sm",
    lg: "px-5 py-2.5 text-sm",
  };
  const variants = {
    default: "bg-sky-600 text-white hover:bg-sky-700",
    outline: "border border-slate-300 text-slate-800 hover:bg-slate-100",
  };
  return (
    <button className={`${base} ${rounded} ${sizes[size] || sizes.base} ${variants[variant] || variants.default} ${className}`} {...props}>
      {children}
    </button>
  );
}
