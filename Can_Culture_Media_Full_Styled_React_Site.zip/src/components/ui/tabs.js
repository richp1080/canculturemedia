import React, { createContext, useContext, useState } from 'react';
const TabsCtx = createContext();
export function Tabs({ defaultValue, className = "", children }) {
  const [value, setValue] = useState(defaultValue);
  return <TabsCtx.Provider value={{ value, setValue }}><div className={className}>{children}</div></TabsCtx.Provider>;
}
export function TabsList({ className="", children }) {
  return <div className={`inline-flex gap-2 p-1 bg-white border border-slate-200 rounded-md ${className}`}>{children}</div>;
}
export function TabsTrigger({ value, children }) {
  const { value: v, setValue } = useContext(TabsCtx);
  const active = v === value;
  return (
    <button
      onClick={() => setValue(value)}
      className={`px-3 py-1.5 text-sm rounded ${active ? "bg-sky-600 text-white" : "bg-transparent hover:bg-slate-100"}`}
    >
      {children}
    </button>
  );
}
export function TabsContent({ value, className="", children }) {
  const { value: v } = useContext(TabsCtx);
  if (v !== value) return null;
  return <div className={className}>{children}</div>;
}
