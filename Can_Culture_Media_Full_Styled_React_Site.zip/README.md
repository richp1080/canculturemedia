# Can Culture Media – React Site (Full Styled Version)

This is a ready-to-deploy React project (Create React App + TailwindCSS) with lightweight UI components and animations.

## Quick Start
```bash
npm install
npm start
```

## Build for Production
```bash
npm run build
```

## Deploy
- Push to GitHub, then connect to Netlify or Vercel.
- Or drag the `/build` folder to static hosting.

## Notes
- UI components live in `src/components/ui` (Card, Button, Tabs, Input, Textarea).
- Edit content in `src/App.js`.
- Tailwind is preconfigured via `tailwind.config.js` and `postcss.config.js`.
